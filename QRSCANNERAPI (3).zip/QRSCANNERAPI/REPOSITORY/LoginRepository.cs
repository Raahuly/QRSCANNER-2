﻿using Dapper;
using MODEL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REPOSITORY
{
    public class LoginRepository
    {
        private readonly Connection _connection;

        public LoginRepository(Connection connection)
        {
            _connection = connection;
        }

        public RegisterModel Login(RegisterModel RM)
        {
            RegisterModel res = new RegisterModel();
            string sql = "[dbo].[LOGINSP]";
            using (IDbConnection conn = _connection.GetConnection())
            {
                var multi = conn.QueryMultiple(sql, new
                {
                    RM.USERNAME,
                    RM.PASSWORD
                }, commandType: CommandType.StoredProcedure);
                res = multi.Read<RegisterModel>().SingleOrDefault();
            }
            return res;
        }

    }
}
