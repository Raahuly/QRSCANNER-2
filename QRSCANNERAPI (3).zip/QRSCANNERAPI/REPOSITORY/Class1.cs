﻿namespace REPOSITORY
{
    public class Class1
    {

    }
}