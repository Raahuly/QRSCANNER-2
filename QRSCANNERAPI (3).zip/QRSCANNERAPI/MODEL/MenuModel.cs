﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class MenuModel
    {
        public Int32? RowNum { get; set; }
        public int? MENUID { get; set; }
        public int? PARENTID { get; set; }
        public string? MENUNAME { get; set; }
        public int? ACCESSIBLE { get; set; }
        public string? CONTROLLERNAME { get; set; }
        public string? ACTIONNAME { get; set; }
        public int? ACTIVE { get; set; }
    }
}
