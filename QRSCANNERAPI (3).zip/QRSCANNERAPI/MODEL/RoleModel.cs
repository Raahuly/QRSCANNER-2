﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class RoleModel
    {
        public string? Param { get; set; }
        public Int32? RowNum { get; set; }
        public int? RoleId { get; set; }
        public string? RoleName { get; set; }
        public int? Active { get; set; }
    }
}
