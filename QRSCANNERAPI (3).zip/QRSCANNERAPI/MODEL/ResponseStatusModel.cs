﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class ResponseStatusModel
    {
        public string? MSG { get; set; }
        public string? STATUS { get; set; }
        public int? N { get; set; }
    }
}
