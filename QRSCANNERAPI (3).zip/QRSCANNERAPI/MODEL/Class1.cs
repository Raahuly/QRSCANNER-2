﻿namespace MODEL
{
    public class Class1
    {

    }
}