﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MODEL;
using REPOSITORY;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace QRSCANNERAPI.Controllers
{
    [Route("api/controller/Login")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly string _jwt;
        private readonly LoginRepository _service;

        public LoginController(IConfiguration configuration, LoginRepository service)
        {
            _jwt = configuration["Jwt:Key"];
            _service = service;
        }

        [HttpPost("CheckLogin")]
        public IActionResult CheckLogin(RegisterModel RM)
        {
            try
            {
                RM = _service.Login(RM);
                if(RM.STATUS == "SUCCESS")
                {
                    var Token = GenerateJwtToken(RM);
                    return Ok(new { Token });
                }
                else
                {
                    return Ok(StatusCodes.Status500InternalServerError);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
            
        private string GenerateJwtToken(RegisterModel user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_jwt); 
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
            new Claim(ClaimTypes.NameIdentifier, user.ID.ToString()),
            new Claim("USERNAME", user.USERNAME ?? string.Empty),
            new Claim("EMAILID", user.EMAILID ?? string.Empty),
            new Claim("ROLENAME", user.ROLENAME ?? string.Empty),
            new Claim("ROLEID", user.ROLEID.HasValue ? user.ROLEID.Value.ToString() : string.Empty)
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

    }
}
