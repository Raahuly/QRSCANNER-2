import axios from 'axios';
import { useState,useRef,useEffect } from 'react';

const RoleForm = () => {
    const RoleValue = useRef();
  const [roles, setRoles] = useState([]);
  const [roleName, setRoleName] = useState('');
  const [buttonText, setButtonText] = useState('Submit'); 
  const [isUpdateMode, setIsUpdateMode] = useState(false);
  const [UpdateId, setUpdateId] = useState(0);
    const fetchRoles = async () => {
        debugger;
        try {
            const response = await axios.get('https://localhost:7087/api/controller/Role/GetAllRole');
            console.log(response.data);
            setRoles(response.data);
        } catch (error) {
            console.log('Error:', error);
            alert('Error fetching roles');
        }
    };

    
 useEffect(() => {
    fetchRoles();
}, []); 

    const handleClick = async () => {
        debugger;
        const roleName = RoleValue.current.value;
        try{
            const response = await axios.post('https://localhost:7087/api/controller/Role/AddRole', {
                RoleName: roleName
            });
            console.log("Response:",response.data);
            alert("Role added successfully!");

             RoleValue.current.value = '';
             fetchRoles(); 
            } catch(error){
                console.log('Error:',error);
                alert("Error adding role");
            }
    }

    const deleteRole = async (roleId) => {
        debugger;
        try{
            const response = await axios.get(`https://localhost:7087/api/controller/Role/DeleteRole?RoleId=${roleId}`);
            console.log(response.data);
            fetchRoles();
        } catch (error) {
            console.log('Error:', error);
            alert('Error fetching roles');
        }
    };



    const EditRole = async (roleId) => {
        debugger;
        try {
            const response = await axios.get(`https://localhost:7087/api/controller/Role/ViewRole?RoleId=${roleId}`);
            console.log(response.data);
            setRoleName(response.data.roleName);
            RoleValue.current.value = response.data.roleName;
            setUpdateId(roleId);
            setIsUpdateMode(true);
            console.log(UpdateId);
        } catch (error) {
            console.log('Error:', error);
            alert('Error fetching roles');
        }
    };
    

      const handleUpdateClick = async(UpdateId) => {
        debugger;
        console.log(UpdateId);
        let UpdateRoleValue = RoleValue.current.value;
        try{
            const response = await axios.post('https://localhost:7087/api/controller/Role/UpdateRole', {
                RoleName: UpdateRoleValue,
                RoleId: UpdateId
            });
            console.log("Response:",response.data);
            var Button = document.getElementById("ButtonSubmit");
            var UpdateButton = document.getElementById("UpdateButton");
            Button.style.display = 'block';
            UpdateButton.style.display = 'none';
            console.log(UpdateId);
             RoleValue.current.value = '';
             fetchRoles(); 
            } catch(error){
                console.log('Error:',error);
                alert("Error adding role");
            }
      }

    return(
        <>
        <div className="container mt-5 mb-5">
          <h2 className="mb-4">Add Role</h2>
          <form>
            <div className="form-group mb-3">
              <label htmlFor="RoleName">Role Name</label>
              <input
                type="text"
                className='form-control'
                id='RoleName'
                ref={RoleValue}
                placeholder='Enter Role Name'
              />
            </div>
  
            {!isUpdateMode ? (
        <button
          type="button"
          className="btn btn-primary"
          id="ButtonSubmit"
          onClick={handleClick}
        >
          Submit
        </button>
      ) : (
        <button
          type="button"
          className="btn btn-primary"
          id="UpdateButton"
          onClick={() => handleUpdateClick(updateId)}
        >
          Update
        </button>
      )}
            <button
              type='button'
              className='btn btn-danger mx-0'
              onClick={() => {
                RoleValue.current.value = '';
              }}
            >
              Reset
            </button>
          </form>
  
          <div className='mt-5 container'>
            <table className="table table-striped table-hover text-center">
              <thead>
                <tr>
                  <th scope="col">SR NO.</th>
                  <th scope="col">Role Name</th>
                  <th scope="col">Operations</th>
                </tr>
              </thead>
              <tbody>
                {roles.map((role, index) => (
                  <tr key={role.roleId}>
                    <th scope="row">{role.rowNum}</th>
                    <td>{role.roleName}</td>
                    <td>
                      <button className="btn btn-warning" onClick={() => EditRole(role.roleId)}>Edit</button>
                      <button className="btn btn-danger ms-2" onClick={() => deleteRole(role.roleId)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </>
    );
  };
  
  export default RoleForm;


    