import axios from 'axios';
import { useState, useRef, useEffect } from 'react';

const RegisterForm = () => {
    const UserName = useRef();
    const Email = useRef();
    const Password = useRef();
    const CPassword = useRef();
    const Number = useRef();
    const Address = useRef();
    const [roles, setRoles] = useState([]);
    const [selectedRoleId, setSelectedRoleId] = useState('');
    const [selectedRoleName, setSelectedRoleName] = useState('');

    const fetchRoles = async () => {
        try {
            const response = await axios.get('https://localhost:7087/api/controller/Role/GetAllRole');
            console.log(response.data);
            setRoles(response.data);
        } catch (error) {
            console.log('Error:', error);
            alert('Error fetching roles');
        }
    };

    useEffect(() => {
        fetchRoles();
    }, []);

    // Function to handle the role change
    const handleRoleChange = (e) => {
        const selectedRoleId = e.target.value;
        const selectedRole = roles.find(role => role.roleId === parseInt(selectedRoleId));
        
        setSelectedRoleId(selectedRoleId);
        setSelectedRoleName(selectedRole ? selectedRole.roleName : '');
    };

    const handleSubmit =  async() => {
        debugger;
        const data = {
            USERNAME: UserName.current.value,
            EMAILID: Email.current.value,
            PASSWORD: CPassword.current.value,
            MOBILENO: Number.current.value,
            ADDRESS: Address.current.value,
            ROLEID: selectedRoleId, 
            ROLENAME: selectedRoleName 
        };
        console.log("Submitted Data:", data);
        try{
            const response = await axios.post('https://localhost:7087/api/controller/Register/AddRegister', data);
            debugger;
            UserName.current.value = '',
            Email.current.value = '',
            CPassword.current.value = '',
            Number.current.value = '',
            Address.current.value = '',
            setSelectedRoleId('');  
            setSelectedRoleName(''); 
            console.log("Response:",response.data);
            alert("Role added successfully!");
            fetchRoles(); 
            } catch(error){
                console.log('Error:',error);
                alert("Error adding role");
            }

         };

    return (
        <>
            <div className='container w-50 mt-5 mb-5'>
                <form action="">
                    <div className="mb-3">
                        <label htmlFor="UserName" className="form-label">User Name</label>
                        <input type="text" id='UserName' ref={UserName} className="form-control" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Email" className="form-label">Email</label>
                        <input type="email" id='Email' ref={Email} className="form-control" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Password" className="form-label">Password</label>
                        <input type="password" id='Password' ref={Password} className="form-control" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="CPassword" className="form-label">Confirm Password</label>
                        <input type="password" id='CPassword' ref={CPassword} className="form-control" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Number" className="form-label">Mobile No.</label>
                        <input type="text" id='Number' ref={Number} className="form-control" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Address" className="form-label">Address</label>
                        <input type="text" id='Address' ref={Address} className="form-control" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Role" className="form-label">Role</label>
                        <select
                            className="form-select"
                            aria-label="Select Role"
                            value={selectedRoleId}
                            onChange={handleRoleChange} 
                        >
                            <option value="">Select Role</option>
                            {roles.map((role) => (
                                <option key={role.roleId} value={role.roleId}>
                                    {role.roleName}
                                </option>
                            ))}
                        </select>
                    </div>
                    <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                        Submit
                    </button>
                    <button type='reset' className='btn btn-danger mx-2'>Reset</button>
                </form>
            </div>
        </>
    );
};

export default RegisterForm;
