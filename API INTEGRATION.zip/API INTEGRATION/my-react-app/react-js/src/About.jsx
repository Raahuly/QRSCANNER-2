const About = () => {
    return <h2>About Page</h2>
}

export default About;