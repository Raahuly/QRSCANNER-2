import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import Navbar from './Navbar';
import Home from './Home';
import About from './About';
import Contact from './Contact';
import RoleForm from './Master Pages/RoleMaster';
import RegisterForm from './Master Pages/Register'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';


const App = () => {
  return   <Router>
  <Navbar />
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/about" element={<About />} />
    <Route path="/contact" element={<Contact />} />
    <Route path="/RoleForm" element={<RoleForm />} />
    <Route path="/RegisterForm" element={<RegisterForm />} />
  </Routes>
</Router>
}

export default App;